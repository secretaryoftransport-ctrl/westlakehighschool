# Westlake High School Website

A complete multi-page, responsive static school website with a browser-based administrative portal. The project uses HTML, CSS, JavaScript, and JSON and includes the supplied Westlake branding graphics.

## Project structure

- `index.html` — public homepage
- `pages/` — individual public website pages
- `admin/` — administrative portal
- `css/` — shared styling
- `js/` — public-site and admin JavaScript
- `data/` — editable seed data
- `assets/images/` — supplied Westlake logo and lion artwork

## Run locally

Do not double-click the HTML files if you want the JSON-powered content to load. Use a local HTTP server.

### Python

1. Extract the ZIP.
2. Open a terminal in the extracted `Westlake-High-School-Website` folder.
3. Run:

```bash
python -m http.server 8080
```

4. Open `http://localhost:8080/`.

### Node.js

Any simple static server can be used. No npm packages are required.

## Administrative portal

Open `/admin/`.

Demo credentials:

- Username: `admin`
- Password: `WestlakeAdmin2026!`

The portal supports editing staff, news, and calendar events. Changes are persisted in browser `localStorage` so they survive page refreshes in the same browser.

## Important production security note

The included portal is a functional front-end demonstration and is **not production-secure authentication**. A public school deployment should replace browser-only authentication/localStorage with a server-side application, database, hashed passwords, secure sessions, role-based authorization, CSRF protection, audit logging, HTTPS, backups, and controlled file uploads.

## Content accuracy

Official school address, phone number, email, personnel, statistics, accreditation information, and policy details were intentionally not invented. They are clearly marked as editable placeholders until verified information is supplied.

## Deployment

The public pages can be deployed to any standard static web host. For the administrative portal to be genuinely multi-user and secure, connect the admin UI to a server-side backend/database before production use.
